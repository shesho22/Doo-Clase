package co.edu.uco.publiuco.crosscutting.exception;

public enum ExceptionType {
	
	DATA, BUSINESS, API, DTO, ENTITY, CROSSCUTTING, GENERAL

}
