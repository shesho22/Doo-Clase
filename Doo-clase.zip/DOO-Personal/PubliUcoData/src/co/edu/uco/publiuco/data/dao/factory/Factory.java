package co.edu.uco.publiuco.data.dao.factory;

public enum Factory {
	SQLSERVER, POSTGRESQL

}
