package co.edu.uco.publiuco.data.dao.relational.sqlserver;

import java.sql.Connection;
import java.util.List;

import co.edu.uco.publiuco.data.dao.EstadoTipoRelacionInstitucionDAO;
import co.edu.uco.publiuco.entities.EstadoTipoRelacionInstitucionEntity;

public final class EstadoTipoRelacionInstitucionSQLServerDAO 
implements EstadoTipoRelacionInstitucionDAO{
	
	public EstadoTipoRelacionInstitucionSQLServerDAO(final Connection connection) {
		
	}

	@Override
	public final void create(final EstadoTipoRelacionInstitucionEntity entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public final List<EstadoTipoRelacionInstitucionEntity> read(final EstadoTipoRelacionInstitucionEntity entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public final void update(final EstadoTipoRelacionInstitucionEntity entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public final void delete(final EstadoTipoRelacionInstitucionEntity entity) {
		// TODO Auto-generated method stub
		
	}

	
}
